BROKIE — launch-ready static website
=====================================

Files:
- index.html: responsive one-page website; no build tools or paid dependencies.
- README.txt: this guide.

Preview:
Open index.html in a browser.

Free publishing options:
1. GitHub Pages (public repository): upload index.html, enable Pages in repository settings.
2. Cloudflare Pages: create a Pages project and upload the static site.

Before publishing:
- Search for existing BROKIE marks, domains and social handles. The name/ticker are provisional.
- Replace placeholder community text only after accounts are actually created and controlled by you.
- Do not add a token address until a real contract has been deployed and independently verified.
- Check local legal, tax, consumer-protection and crypto-asset requirements before any token issuance or promotion.
- Do not solicit deposits or promise returns.

Current status:
This is a static concept website, not a deployed live website. No token, contract, wallet, presale or social account has been created.
